package com.yyd.SportsClub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsClubApplicationTests {

	@Test
	void contextLoads() {
	}

}
