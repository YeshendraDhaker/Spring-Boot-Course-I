package com.yyd.SportsClub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsClubApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportsClubApplication.class, args);
	}

}
