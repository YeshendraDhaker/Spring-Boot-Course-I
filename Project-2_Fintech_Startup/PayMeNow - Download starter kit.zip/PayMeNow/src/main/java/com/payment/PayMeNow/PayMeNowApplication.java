package com.payment.PayMeNow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayMeNowApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayMeNowApplication.class, args);
	}

}
