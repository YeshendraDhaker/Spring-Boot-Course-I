package com.payment.PayMeNow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayMeNowApplicationTests {

	@Test
	void contextLoads() {
	}

}
